package com.dependencyinjection.SpringDependecyInjection;

interface Allocator
{
	void taskAllocation(String user);

}
